#pragma once
#include <string>
#include <vector>
#include <iostream>
#include "Transform3D.h"
#include "Structures.h"

class Lane
{
public:
	std::vector<platforma> p_center;
	Lane();
	Lane(float start, float tx);
	~Lane();

	void PlatformGenerator();
	double random_number(int start, int end);
	void StartPlatforms(float start);

private:
	float max_z = -30;
	bool center_empty = false;
	platforma aux;
	float tx;
};