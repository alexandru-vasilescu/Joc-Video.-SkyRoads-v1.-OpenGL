#include "Tema2.h"

using namespace std;
using namespace Transform3D;

Tema2::Tema2()
{
}

Tema2::~Tema2()
{
}
void Tema2::restart()
{
	while (!lanes.empty())
		lanes.erase(lanes.begin());
	renderCameraTarget = false;

	camera = new Camera();
	camera->Set(glm::vec3(0, 2, 3), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	{
		Lane* l;
		l = new Lane(camera->position.z, 0);
		lanes.push_back(l);
		l = new Lane(camera->position.z, 5);
		lanes.push_back(l);
		l = new Lane(camera->position.z, -5);
		lanes.push_back(l);
	}
	{
		pers.tx = camera->position.x;
		pers.ty = 0.1 + pers.sy;
		pers.tz = camera->position.z;
	}
	speed = 2;
	start = false;
	gravity = -2;
	fall = false;
	super_speed = 0;
	buff_duration = 5;
	death = 0;
	time_of_death = 0;
	combustibil = 50;
	modified = false;
	Score = 0;
	printed = false;
}
void Tema2::Init()
{
	restart();
	{
		colors.push_back(glm::vec3(0, 0, 1));
		colors.push_back(glm::vec3(1, 0, 0));
		colors.push_back(glm::vec3(1, 1, 0));
		colors.push_back(glm::vec3(1, 0.5, 0));
		colors.push_back(glm::vec3(0, 1, 0));
	}
	FoV = RADIANS(60);
	
	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Shader* shader = new Shader("Tema2");
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}
	//combustibil
	{
		vector<VertexFormat> vertices{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0)),
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(0, 1, 0), glm::vec3(1, 1, 0)),
			VertexFormat(glm::vec3(1,1,0), glm::vec3(1,0,0))
		};
		vector<unsigned short> indices{
			0,1,2,
			1,3,2
		};
		Mesh* mesh = new Mesh("Combustibil");
		mesh->InitFromData(vertices, indices);
		meshes[mesh->GetMeshID()] = mesh;
	}
	//combustibil background
	{
		vector<VertexFormat> vertices{
			VertexFormat(glm::vec3(-0.1,-0.1,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(1.1, -0.1, 0), glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(-0.1, 1.1, 0), glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(1.1,1.1,0), glm::vec3(1,1,1))
		};
		vector<unsigned short> indices{
			0,1,2,
			1,3,2
		};
		Mesh* mesh = new Mesh("Combustibil2");
		mesh->InitFromData(vertices, indices);
		meshes[mesh->GetMeshID()] = mesh;
		
	}
	projectionMatrix = glm::perspective(FoV, window->props.aspectRatio, 0.01f, 200.0f);
}
void Tema2::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}
bool Tema2::PlatformMove(float deltaTimeSeconds, platforma* p, bool collision)
{
	if (p->tz < camera->position.z + p->sz/2)
	{
		if (start)
			p->tz += deltaTimeSeconds * speed;
		if(!p->empty)
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix *= Translate(p->tx, 0, p->tz);
			modelMatrix *= Scale(p->sx, p->sy, p->sz);
			RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, (int)collision,0,colors[p->power]);
		}
		return false;
	}
	return true;
}

bool Tema2::LaneMove(Lane* lane, float deltaTimeSeconds)
{
	bool any_platform = false;
	for (int i = 0; i < lane->p_center.size(); i++)
	{
		bool collision = false;
		if(!lane->p_center[i].empty)
		{
			collision = colide(&lane->p_center[i]);
			any_platform = any_platform | collision;
		}
		if (PlatformMove(deltaTimeSeconds, &lane->p_center[i], collision))
		{
			lane->p_center.erase(lane->p_center.begin());
		}
	}
	return any_platform;
}
bool Tema2::colide(platforma* p)
{
	if(pers.ty - pers.sy > -0.1 && pers.ty - pers.sy < 0.1)
	{
		if (pers.tz > p->tz - p->sz/2 && pers.tz < p->tz + p->sz/2 && pers.tx > p->tx - p->sx/2 && pers.tx < p->tx + p->sx/2) {
			if (p->power == 3)
				super_speed = 1;
			if (p->power == 1) {
				death = 1;
				start = 0;
			}
			if (p->power == 2 && !modified)
			{
				combustibil -= 5;
				modified = true;
			}
			if (p->power == 4 && !modified)
			{
				if (combustibil < 30)
					combustibil += 20;
				else
					combustibil = 50;
				modified = true;
			}
			return true;
		}
	}
	return false;
}
void Tema2::Update(float deltaTimeSeconds)
{
	if(!start && !death)
	{
		cout << "PRESS P TO START" << endl;
	}
	if (start) {
		Score += speed;
		combustibil -= deltaTimeSeconds;
	}
	if (combustibil < 0)
		death = 1;
	if(pers.ty < -3)
	{
		death = 1;
	}
	if(death && time_of_death < 1)
	{
		start = 0;
		time_of_death += deltaTimeSeconds;
	}
	if (time_of_death > 1 && !printed) {
		cout << "SCORE: " << Score << endl;
		cout << "PRESS R TO RESTART!" << endl;
		printed = true;
	}
	
	if(super_speed == 1 && start)
	{
		speed = 10;
		buff_duration -= deltaTimeSeconds;
	}
	if(buff_duration < 0 && start)
	{
		buff_duration = 10;
		speed = min_speed;
		super_speed = 0;
	}
	bool any_platform = false;
	for (Lane* l : lanes) {
		l->PlatformGenerator();
		any_platform = any_platform | LaneMove(l, deltaTimeSeconds);
	}
	fall = any_platform;
	if (gravity > min_gravity)
		gravity -= deltaTimeSeconds;
	if (start && !fall)
		pers.ty += gravity * deltaTimeSeconds;
	if (pers.jump) {
		pers.ty += gravity * deltaTimeSeconds;
		if (gravity < 0) {
			pers.jump = false;
			modified = false;
		}
	}
	if (renderCameraTarget)
	{
		camera->position = glm::vec3(pers.tx, pers.ty + 1, pers.tz + 3);
	
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(pers.tx, pers.ty, pers.tz);
		modelMatrix *= Scale(pers.sx, pers.sy, pers.sz);
		if(time_of_death < 1)
		RenderSimpleMesh(meshes["sphere"], shaders["Tema2"], modelMatrix, 0,1, glm::vec3(1,1,1));
	}
	else
	{
		camera->position = glm::vec3(pers.tx, pers.ty, pers.tz);
	}
	{
		glm::mat3 modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(1.2, 2);
		modelMatrix *= Transform2D::Scale(combustibil/50, 0.1);
		RenderMesh2D(meshes["Combustibil"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(1.2, 2);
		modelMatrix *= Transform2D::Scale(1, 0.1);
		RenderMesh2D(meshes["Combustibil2"], shaders["VertexColor"], modelMatrix);
	}
}

void Tema2::FrameEnd()
{
	 // DrawCoordinatSystem(camera->GetViewMatrix(), projectionMatrix);
}

void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, int collision,int is_person, const glm::vec3& color)
{
	if (!mesh || !shader || !shader->program)
		return;

	glUseProgram(shader->program);
	
	glUniform3fv(glGetUniformLocation(shader->program, "object_color"), 1, glm::value_ptr(color));
	
	// render an object using the specified shader and the specified position
	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = camera->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	glUniform1i(glGetUniformLocation(shader->program, "collision"), collision);
	glUniform1i(glGetUniformLocation(shader->program, "pers"), is_person);
	glUniform1i(glGetUniformLocation(shader->program, "superspeed"), super_speed);
	glUniform1i(glGetUniformLocation(shader->program, "death"), death);
	glUniform1f(glGetUniformLocation(shader->program, "time"), time_of_death);
	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);

}


void Tema2::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->KeyHold(GLFW_KEY_W) && start) {
		if (speed < max_speed && super_speed == 0)
			speed += deltaTime;
	}
	if (window->KeyHold(GLFW_KEY_S) && start) {
		if (speed > min_speed && super_speed == 0)
			speed -= deltaTime;
	}
	if (window->KeyHold(GLFW_KEY_A) && start) {
		pers.tx -= deltaTime * pers.speed;
	}
	if (window->KeyHold(GLFW_KEY_D) && start) {
		pers.tx += deltaTime * pers.speed;
	}
}

void Tema2::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_C)
	{
		renderCameraTarget = !renderCameraTarget;
	}
	if (key == GLFW_KEY_P)
	{
		start = !start;
	}
	if (key == GLFW_KEY_SPACE && fall && start)
	{
		pers.jump = true;
		gravity = max_gravity;
	}
	if (key == GLFW_KEY_R && !start)
	{
		restart();
	}
}

void Tema2::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema2::OnWindowResize(int width, int height)
{
}