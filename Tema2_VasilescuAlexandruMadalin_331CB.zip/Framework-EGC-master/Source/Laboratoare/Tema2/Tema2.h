#pragma once
#include <Component/SimpleScene.h>
#include <string>
#include <Core/Engine.h>
#include <vector>
#include <iostream>
#include "Camera.h"
#include "Transform3D.h"
#include "Structures.h"
#include "Lane.h"
#include "Transform2D.h"


class Tema2 : public SimpleScene
{
public:
	Tema2();
	~Tema2();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, int colide,int is_person, const glm::vec3& color = glm::vec3(1));

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	bool PlatformMove(float deltaTimeSeconds, platforma* p, bool collision);
	bool LaneMove(Lane* l, float deltaTimeSeconds);
	bool colide(platforma* p);
	void restart();
	
protected:
	Camera* camera;
	glm::mat4 projectionMatrix;
	bool renderCameraTarget;
	float FoV;
	//platforme
	std::vector<Lane*> lanes;
	std::vector<glm::vec3> colors;
	float speed = 2;
	float max_speed = 4;
	float min_speed = 2;
	//personaj
	personaj pers;
	bool start = false;
	float gravity = -2;
	float min_gravity = -2;
	float max_gravity = 1;
	bool fall = false;
	int super_speed = 0;
	float buff_duration = 5;
	int death = 0;
	float time_of_death = 0;
	float combustibil = 50;
	bool modified = false;
	int Score = 0;
	bool printed = false;
};