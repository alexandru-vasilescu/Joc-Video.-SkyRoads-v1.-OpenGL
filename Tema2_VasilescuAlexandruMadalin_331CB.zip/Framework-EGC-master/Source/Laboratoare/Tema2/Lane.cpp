#include "Lane.h"

using namespace std;
using namespace Transform3D;

Lane::Lane()
{
}

Lane::Lane(float start_position, float tx)
{
	this->tx = tx;
	StartPlatforms(start_position);
}

Lane::~Lane()
{
}
double Lane::random_number(int start, int end)
{
	double x = (double)rand() / RAND_MAX;
	return start + (end - start) * x;
}
void Lane::StartPlatforms(float start_position)
{
	float z_center;
	z_center = start_position;
	while (z_center >= max_z)
	{
		platforma p;
		p.power = 0;
		p.empty = center_empty;
		center_empty = !center_empty;
		if (p.empty)
			p.sz = random_number(2,4);
		else
			p.sz = random_number(4, 16);
		p.sx = random_number(2, 4);
		if(!p_center.empty())
			z_center -= p.sz / 2;
		p.tz = z_center;
		p.tx = this->tx;
		z_center -= p.sz/2;
		p_center.push_back(p);
	}
	aux.empty = center_empty;
	center_empty = !center_empty;
	if (aux.empty)
		aux.sz = 2;
	aux.tz = max_z;
	aux.tx = this->tx;
}

void Lane::PlatformGenerator()
{
	platforma p = p_center[p_center.size() - 1];
	if (aux.tz <= p.tz - p.sz / 2 - aux.sz / 2)
	{
		p_center.push_back(aux);
		
		aux.empty = center_empty;
		center_empty = !center_empty;
		if (aux.empty)
			aux.sz = random_number(2, 5);
		else
			aux.sz = random_number(4, 10);
		aux.sx = random_number(2, 4);
		aux.tz = max_z;
		aux.tx = this->tx;
		float power = random_number(0, 100);
		if (power < 60) aux.power = 0;                 //normal
		if (power < 70 && power >= 60) aux.power = 1;  //death
		if (power < 80 && power >= 70) aux.power = 2;  //reduce fuel
		if (power < 90 && power >= 80) aux.power = 3;  //superspeed
		if (power >= 90) aux.power = 4;				   //add fuel
	}
}