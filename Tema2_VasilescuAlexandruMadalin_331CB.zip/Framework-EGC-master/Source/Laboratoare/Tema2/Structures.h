#pragma once

struct platforma
{
	float tx, tz;
	float sx = 3, sy = 0.2, sz = 4;
	bool empty;
	int power;
};

struct personaj
{
	float tx, tz, ty;
	float sx = 0.5, sy = 0.5, sz = 0.5;
	float speed = 2;
	bool jump = false;
	int alive = 1;
	int super_speed = 1;
};